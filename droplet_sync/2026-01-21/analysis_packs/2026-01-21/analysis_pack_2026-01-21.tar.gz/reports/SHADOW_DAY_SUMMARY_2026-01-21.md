# Shadow Day Summary (v2) — 2026-01-21

## 1. Overview
- Shadow trade candidates: **6**
- Unique symbols: **1**
- Sectors: **{'UNKNOWN': 6}**

## 2. Biggest would-be winners/losers (by v2 score, best-effort)
### Top 5
- **AAPL** v2_score=3.6 v1_score=3.2 dir=bullish
- **AAPL** v2_score=3.6 v1_score=3.2 dir=bullish
- **AAPL** v2_score=3.6 v1_score=3.2 dir=bullish
- **AAPL** v2_score=3.6 v1_score=3.2 dir=bullish
- **AAPL** v2_score=3.6 v1_score=3.2 dir=bullish

### Bottom 5
- **AAPL** v2_score=3.6 v1_score=3.2 dir=bullish
- **AAPL** v2_score=3.6 v1_score=3.2 dir=bullish
- **AAPL** v2_score=3.6 v1_score=3.2 dir=bullish
- **AAPL** v2_score=3.6 v1_score=3.2 dir=bullish
- **AAPL** v2_score=3.6 v1_score=3.2 dir=bullish

## 3. UW feature usage summary (count of non-zero adjustments)
- No UW adjustment usage detected in logged candidates.

## 4. Regime timeline vs v2 behavior (snapshot)
- Regime: **BEAR** (conf 0.9622)

## 5. Paper P&L estimate (placeholder)
- This summary currently ranks candidates by **v2 score**. To compute paper P&L, wire shadow positions/exits into `shadow_trades.jsonl` (future additive enhancement).

## Inputs
- shadow_trades: `logs/shadow_trades.jsonl` exists=True
- uw_attribution: `logs/uw_attribution.jsonl` exists=True
- uw_intel_pnl_summary: `state/uw_intel_pnl_summary.json` exists=True
