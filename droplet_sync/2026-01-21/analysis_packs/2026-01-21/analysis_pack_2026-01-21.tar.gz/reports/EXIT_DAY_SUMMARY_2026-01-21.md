# Exit Day Summary (v2) — 2026-01-21

## Summary
- Exit attributions: **3**

## Best exits (paper P&L, if available)
- No P&L data available yet (exit_price not captured in shadow positions).

## Worst exits (paper P&L, if available)
- No P&L data available yet.

## Exit score analysis
- exit_score_stats: `{'max': None, 'mean': None, 'min': None, 'n': 0}`

## UW deterioration patterns (placeholder)
- Best-effort: uses components in `logs/exit_attribution.jsonl` (v2_exit_components).

