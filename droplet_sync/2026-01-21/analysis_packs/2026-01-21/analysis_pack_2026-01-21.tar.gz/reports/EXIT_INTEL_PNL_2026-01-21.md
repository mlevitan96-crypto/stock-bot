# Exit Intel P&L — 2026-01-21

## Summary
- Exit attributions: **3**

## Win rate / Avg P&L by exit reason
- **profit**: n=3, win_rate=0.0, avg_pnl=0.0

## Regime impact (avg P&L)

## Sector impact (avg P&L)

## Time in trade distribution
- {}

