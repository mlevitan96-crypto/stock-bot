# Intel Dashboard — 2026-01-21

## 1. Universe Overview
- Daily universe (v1): **20**
- Daily universe (v2, shadow-only): **20**
- Universe v1 version: `2026-01-20_universe_v1`
- Universe v2 version: `2026-01-20_universe_v2`

## 2. Premarket/Postmarket Intel
- Premarket intel symbols: **20** (version `2026-01-20_uw_v1`)
- Postmarket intel symbols: **20** (version `2026-01-20_uw_v1`)

## 3. Regime & Sector Profiles
- Regime: **BEAR** (conf 0.9622)
- Regime engine version: `2026-01-20_regime_v1`

## 4. UW Attribution Highlights (tail)
- **RIVN** dir=bullish uw_score_delta=0.0
- **MSFT** dir=bearish uw_score_delta=0.0
- **XLI** dir=bullish uw_score_delta=0.0
- **BAC** dir=bearish uw_score_delta=0.0
- **WMT** dir=bullish uw_score_delta=0.0
- **XLE** dir=bearish uw_score_delta=0.0
- **COP** dir=bullish uw_score_delta=0.0
- **PFE** dir=bullish uw_score_delta=0.0
- **TGT** dir=bullish uw_score_delta=0.0
- **AAPL** dir=bullish uw_score_delta=0.0

## 5. UW Intel P&L Summary
- Attribution records: **6393**, matched: **0**
- No per-feature P&L aggregates available yet.

## 6. Health & Self-Healing Status
- Health: **NOT_OK**
- Checks: **18**
  - freshness:daily_universe: ok
  - freshness:core_universe: ok
  - freshness:daily_universe_v2: ok
  - freshness:premarket_intel: ok
  - freshness:postmarket_intel: ok
  - freshness:uw_usage_state: ok
  - freshness:regime_state: ok
  - freshness:uw_intel_pnl_summary: ok
  - schema:daily_universe: ok
  - schema:core_universe: ok
  - schema:daily_universe_v2: ok
  - schema:premarket_intel: ok

## 7. UW Flow Daemon Health
- Status: **healthy**
- PID ok: **True** (ExecMainPID=1648893)
- Lock ok: **True** (lock_pid=1648893, held=True)
- Poll fresh: **True** (age_sec=5.582501649856567)
- Crash loop: **False** (restarts=0)
- Endpoint errors: **False** (counts={'uw_invalid_endpoint_attempt': 1, 'uw_rate_limit_block': 1})
- Self-heal attempted: **False** (success=None)

## 8. Shadow Trading Snapshot (v2)
- Shadow trade candidates today: **6**
- Top symbols by v2 activity:
  - **AAPL**: 6
- Top 5 candidates (by v2 score):
  - **AAPL** v2=3.6 v1=3.2 dir=bullish
  - **AAPL** v2=3.6 v1=3.2 dir=bullish
  - **AAPL** v2=3.6 v1=3.2 dir=bullish
  - **AAPL** v2=3.6 v1=3.2 dir=bullish
  - **AAPL** v2=3.6 v1=3.2 dir=bullish
- Bottom 5 candidates (by v2 score):
  - **AAPL** v2=3.6 v1=3.2 dir=bullish
  - **AAPL** v2=3.6 v1=3.2 dir=bullish
  - **AAPL** v2=3.6 v1=3.2 dir=bullish
  - **AAPL** v2=3.6 v1=3.2 dir=bullish
  - **AAPL** v2=3.6 v1=3.2 dir=bullish
- v2 score range: 3.60–3.60 (n=6)
- v1 score range: 3.20–3.20 (n=6)
- Regime overlay: **BEAR**

## 9. Exit Intelligence Snapshot (v2)
- Exit attributions: **3**
- Exit count / avg P&L by reason:
  - **profit**: n=3, win_rate=0.0, avg_pnl=0.0
- Exit score stats: `{'max': 0.5, 'mean': 0.5, 'min': 0.5, 'n': 3}`

## 10. Post-Close Analysis Pack
- Pack folder: `analysis_packs/2026-01-21/`
- Master summary: `analysis_packs/2026-01-21/MASTER_SUMMARY_2026-01-21.md`
- Critical flags: **['intel_health=not_ok']**
