# UW Intel P&L — 2026-01-21

## Summary
- Attribution records: **6393**
- Matched to P&L: **0**

## Per-feature aggregates (best-effort)
- No matches available yet (missing exits/shadow PnL or no attribution records).

## Notes
- This report is **additive** and may be sparse until exit logs or shadow PnL are available.
